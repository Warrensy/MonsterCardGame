﻿namespace MonsterCardGame.Interfaces
{
    interface ICard
    {
        void PrintStats();
        void CardEffect();
    }
}
