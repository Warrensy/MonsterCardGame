﻿namespace MonsterCardGame.Interfaces
{
    interface IUser
    {
        void BuyPackage();
        void TradeCard();
        void RemoveCard();
    }
}
