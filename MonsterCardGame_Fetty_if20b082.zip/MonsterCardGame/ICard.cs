﻿namespace MonsterCardGame
{
    interface ICard
    {
        void PrintStats();
    }
}
